package org.koala.runnersFramework.runners.bot;

public class DiscreteBKPOptimizeCost {

}
