package org.koala.runnersFramework.runners.bot.listener;

public interface MethodReport {

    public void append(String msg) ;

    public void clear() ;
}

