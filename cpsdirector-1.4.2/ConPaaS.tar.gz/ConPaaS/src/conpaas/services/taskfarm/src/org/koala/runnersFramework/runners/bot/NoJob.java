package org.koala.runnersFramework.runners.bot;

import java.util.List;

public class NoJob extends Job {

	public NoJob(List<String> args2, String executable, String jobID) {
		super(args2, executable, jobID);
		// TODO Auto-generated constructor stub
	}

	public NoJob() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
