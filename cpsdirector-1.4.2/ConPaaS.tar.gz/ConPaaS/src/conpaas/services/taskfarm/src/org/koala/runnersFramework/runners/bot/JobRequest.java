package org.koala.runnersFramework.runners.bot;

import java.io.Serializable;

public class JobRequest implements Serializable {

	public JobRequest() {
		// TODO Auto-generated constructor stub
		
	}
	
}
