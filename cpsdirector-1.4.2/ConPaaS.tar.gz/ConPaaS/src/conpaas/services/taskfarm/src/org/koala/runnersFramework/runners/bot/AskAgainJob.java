package org.koala.runnersFramework.runners.bot;

import java.util.List;

public class AskAgainJob extends Job {

	public AskAgainJob(List<String> args2, String executable, String jobID) {
		super(args2, executable, jobID);
		// TODO Auto-generated constructor stub
	}

	public AskAgainJob() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
