This directory contains the implementation of the ConPaaS Web hosting
service. This service supports static Web content as well as Web
applications written in PHP or Java. 

Installation instructions can be found in directory ../doc

Guillaume Pierre
gpierre@cs.vu.nl

