   ======== CONFIGURATION ==========
   
   To configure your manager to use the prediction models you need to install the following modules:
   
   1) sudo apt-get install libatlas-base-dev libatlas3gf-base python-dev python-numpy python-scipy python-setuptools gfortran g++
   	  
   2) sudo easy_install numpy
   	  sudo easy_install -U numpy
   	  
   3) sudo easy_install pandas
   
   4) sudo easy_install scipy
   
   5) sudo easy_install statsmodels
   
   6) sudo easy_install patsy
   