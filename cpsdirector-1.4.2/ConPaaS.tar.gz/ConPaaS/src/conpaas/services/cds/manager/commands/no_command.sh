#!/bin/bash

echo no of arguments: $#
echo arguments: $@
hostname