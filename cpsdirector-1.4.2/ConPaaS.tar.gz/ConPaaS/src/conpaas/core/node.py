# -*- coding: utf-8 -*-

"""
    conpaas.core.node
    =================

    ConPaaS core: service node abstraction.

    :copyright: (C) 2010-2013 by Contrail Consortium.
"""
DEFAULT_WEIGHT = 100


class ServiceNode(object):
    """
    This class represents the abstraction of a node.
    """

    #def __init__(self, vmid, ip, private_ip, cloud_name, agent_port=5555, backend_port=9000, web_port=8080, proxy_port=80, mysql_port=3306, mysql4567_port=4567, mysql4444_port=4444, glb_port=8010, weightBackend=DEFAULT_WEIGHT):
    def __init__(self, vmid, ip, private_ip, cloud_name, weightBackend=DEFAULT_WEIGHT, **kwargs):
        """
        Parameters
        ----------
        vmid : string
            virtual machine (VM) identifier provided by the cloud provider
        ip : string
            public IP address of the VM
        private_ip : string
            private IP address of the VM in a VPN
        cloud_name : string
            name of the cloud provider
        weightBackend : int
            weight of the VM representing the efficiency of this VM
        """
        self.id = "%s%s" % (cloud_name, vmid)
        self.vmid = vmid
        self.ip = ip
        self.private_ip = private_ip
        self.cloud_name = cloud_name
        self.weightBackend = weightBackend

        self.agent_port = kwargs['agent_port'] if 'agent_port' in kwargs else 5555
        self.backend_port = kwargs['backend_port'] if 'backend_port' in kwargs else 9000
        self.web_port = kwargs['web_port'] if 'web_port' in kwargs else 8080
        self.proxy_port = kwargs['proxy_port'] if 'proxy_port' in kwargs else 80
        self.mysql_port= kwargs['mysql_port'] if 'mysql_port' in  kwargs else 3306
        self.mysql4444_port= kwargs['mysql4444_port'] if 'mysql4444_port' in kwargs else 4444
        self.mysql4567_port= kwargs['mysql4567_port'] if 'mysql4567_port' in kwargs else 4567
        self.glb_port= kwargs['glb_port'] if 'glb_port' in kwargs else 8010

        self.servicetype = kwargs['servicetype'] if 'servicetype' in kwargs else 'php'

    def __repr__(self):
        if self.servicetype == 'php':
            return 'ServiceNode(id=%s, ip=%s, agent_port=%s, backend_port=%s, web_port=%s, proxy_port=%s)' % (str(self.id), self.ip, str(self.agent_port), str(self.backend_port), str(self.web_port), str(self.proxy_port))
        elif self.servicetype == 'mysql':
            return 'ServiceNode(id=%s, ip=%s, agent_port=%s, mysql_port=%s, mysql4567_port=%s, mysql4444_port=%s, glb_port=%s)' % (str(self.id), self.ip, str(self.agent_port), str(self.mysql_port), str(self.mysql4567_port), str(self.mysql4444_port), str(self.glb_port))
        else:
            return 'ServiceNode(id=%s, ip=%s, agent_port=%s)' % (str(self.id), self.ip, str(self.agent_port))

    def __cmp__(self, other):
        if self.id == other.id and self.cloud_name == other.cloud_name:
            return 0
        elif self.id < other.id:
            return -1
        else:
            return 1

    def as_libcloud_node(self):
        class Node:
            pass
        n = Node()
        n.id = self.vmid
        n.ip = self.ip
        n.agent_port= self.agent_port
        n.backend_port = self.backend_port
        n.web_port = self.web_port
        n.proxy_port = self.proxy_port
        n.mysql_port = self.mysql_port
        n.mysql4567_port = self.mysql4567_port
        n.mysql4444_port = self.mysql4444_port
        n.glb_port= self.glb_port
        return n
