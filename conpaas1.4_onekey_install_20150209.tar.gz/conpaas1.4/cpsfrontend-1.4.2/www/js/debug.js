function debug_alert(str) {
        if (JS_DEBUG_LEVEL > 0) {
                alert("Debugging: \n" + str);
        }
}
