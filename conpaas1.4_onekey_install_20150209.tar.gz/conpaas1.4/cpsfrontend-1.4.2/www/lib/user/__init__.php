<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'UserData.php');
require_once($dir.'User.php');
