<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'Instance.php');
require_once($dir.'Cluster.php');
require_once($dir.'ManagerInstance.php');
