<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'PageStatus.php');
require_once($dir.'Page.php');
require_once($dir.'PageFactory.php');
require_once($dir.'ServicePage.php');
