<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'HostingPage.php');
require_once($dir.'PhpPage.php');
require_once($dir.'JavaPage.php');
