You must download the AWS JDK for PHP from http://aws.amazon.com/sdkforphp/
and expand it in this directory (thereby creating a directory "aws-jdk" 
containing a number of PHP files and subdirectories).
