Before installation, please make sure your machine can access https://github.com and http://pypi.python.org
If you can not access, build your own ladder, or can not be installed successfully.

Please note:
Need to enter the following parameters when executing ./install.sh

1.Please make sure your version is Havana openstack.
2.your current ConPaaS ip address
3.your openstack ip address
4.openstack administrative account and password, and the tenant name
5.conpaas image in openstack 
6.conpaas flavor in openstack

