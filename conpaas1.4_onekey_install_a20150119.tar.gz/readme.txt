安装前请确保你的机器能访问 https://github.com, http://pypi.python.org及 https://code.google.com
如不能访问，请自行搭建梯子,不然无法安装成功.



请先修改以下文件后再运行./install.sh进行安装
1. 修改cpsdirector-1.4.2/director.cfg.example 文件, 修改以下键值的默认值

注意:只需修改以下的ip地址，帐号，密码，image id， flavor id, 其它如端口,api地址可以不用修改

-----修改openstack的ip,及登录帐号, 使用的image的id和 套餐id-----
DRIVER = openstack
IDENTITY_URL = http://192.168.20.206:5000/v2.0
IDENTITY_ADMIN_URL = http://192.168.20.206:35357/v2.0
COMPUTE_URL = http://192.168.20.206:8774/v2
IMAGE_URL = http://192.168.20.206:9292/v2

USER =  admin
PASSWORD = powerall
TENANT = admin

ADMIN_USER = admin
ADMIN_PASSWORD = powerall
ADMIN_TENANT = admin

IMAGE_ID = 94780e42-342e-4e73-8d04-abb1f725b95c  (在openstack界面上查看)
FLAVOR = 114b6e22-cc83-4a86-9aca-5c4698d884a8    (在openstack界面上查看)


------修改cloudvisor的api地址,默认安装在openstack机器上,端口默认就行---
CV_URL = http://192.168.18.111:8085/server
-----memcached,修改ip就行,端口默认, memcached默认安装在openstack机器上----
MEMCACHED = 192.168.20.206:11211

-------该url是conpaas安装机器的ip,端口默认-----
DIRECTOR_URL = https://192.168.18.115:5555
