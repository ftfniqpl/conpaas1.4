<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'DashboardApplicationUI.php');
require_once($dir.'ApplicationsListUI.php');
//require_once($dir.'Version.php');
