<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'ManagerException.php');
require_once($dir.'ServiceData.php');
require_once($dir.'Service.php');
