<?php
/* Copyright (C) 2010-2013 by Contrail Consortium. */



$dir = dirname(__FILE__).'/';

require_once($dir.'Region.php');
require_once($dir.'Cloud.php');
require_once($dir.'EC2Cloud.php');
require_once($dir.'OpennebulaCloud.php');
require_once($dir.'ZibCloud.php');
require_once($dir.'CloudFactory.php');
require_once($dir.'Manager.php');
require_once($dir.'EC2Manager.php');
require_once($dir.'OpenNebulaManager.php');
